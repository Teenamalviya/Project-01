class Get_files:

    def __init__(self, driver):
        self.driver = driver

    exl_file_path = r'C:\Users\admin\PycharmProjects\project1.xlsx'
    sheet1 = 'Sheet1'
    sheet2 = 'Sheet2'
    image_path = r"C:\Users\admin\PycharmProjects\01.jpg"
    dashboard_url = ('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
    pim_url = ('https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList')
